var express = require('express');
var router = express.Router();


/* Trang fashion mot . */
router.get('/nhan-vat.chn', function(req, res, next) {
    res.send('Day la trang Fashion > Mot ')
  });
   
  

/* Trang fashion mot . */
router.get('/du-lich.chn', function(req, res, next) {
    res.send('Day la trang Fashion > Mot ')
  });
   
  

  module.exports = router ; 